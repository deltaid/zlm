#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "zlm.h"

extern const unsigned char* zlm_get_private_key(int *keylen);

static off_t file_size(const char *path)
{
  struct stat sb;
  if (stat(path, &sb)) {
    fprintf(stderr, "cannot stat file '%s': %s\n", path, strerror(errno));
    exit(EXIT_FAILURE);
  }
  return sb.st_size;
}

static void* xcalloc(size_t nmemb, size_t size)
{
  void *p;
  if (!(p = calloc(nmemb, size))) {
    fprintf(stderr, "out of memory (cannot calloc(%lu, %lu))\n",
            (unsigned long) nmemb, (unsigned long) size);
    exit(EXIT_FAILURE);
  }
  return p;
}

FILE* xfopen(const char *path, const char *mode)
{
  FILE *fp;
  if (!(fp = fopen(path, mode))) {
    fprintf(stderr, "cannot open file '%s': %s\n", path, strerror(errno));
    exit(EXIT_FAILURE);
  }
  return fp;
}

static void xfread(void *ptr, size_t size, size_t nmemb, FILE *fp)
{
  size_t rval;
  if ((rval = fread(ptr, size, nmemb, fp)) < nmemb) {
    if (ferror(fp)) {
      fprintf(stderr, "cannot read from file: %s\n", strerror(errno));
      exit(EXIT_FAILURE);
    }
  }
}

static void xfclose(FILE *fp)
{
  if (fclose(fp)) {
    fprintf(stderr, "cannot close file: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
}

int main(int argc, char *argv[])
{
  char err[ZLM_ERRBUF];
  off_t size;
  char *in, *out;
  FILE *fp;

  if (argc != 2) {
    fprintf(stderr, "Usage: %s [license_file_to_sign]\n", argv[0]);
    fprintf(stderr, "Sign the given license file.\n");
    return EXIT_FAILURE;
  }

  /* read license file */
  size = file_size(argv[1]);
  in = xcalloc(size + 1, sizeof(char));
  fp = xfopen(argv[1], "r");
  xfread(in, 1, size, fp);
  xfclose(fp);

  /* sign license file */
  if (!(out = zlm_sign_license(in, zlm_get_private_key, err))) {
    fprintf(stderr, "%s: error: %s\n", argv[0], err);
    return EXIT_FAILURE;
  }

  /* write license file */
  fp = xfopen(argv[1], "w");
  fprintf(fp, "%s", out);
  zlm_free(out);
  zlm_free(in);
  xfclose(fp);

  return EXIT_SUCCESS;
}
